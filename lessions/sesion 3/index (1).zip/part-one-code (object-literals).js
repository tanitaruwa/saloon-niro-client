let personOne = {
    name : "Carl Johnson",
    health : 100,
    bullets : 50,
    money : 1000,

    run : function(){
        console.log(this.name + " is running");
    },
    jump : function(){
        console.log(this.name + " is jumping");
    },
    shoot : function(){
        console.log(this.name + " is shooting");
        this.bullets = this.bullets - 1
    }
}

let personTwo = {
    name : "Franklin Clinton",
    health : 100,
    bullets : 500,
    money : 1000,

    run : function(){
        console.log(this.name+" is running");
    },
    jump : function(){
        console.log(this.name + " is jumping");
    },
    shoot : function(){
        console.log(this.name + " is shooting");
        this.bullets = this.bullets - 1
    }
}

console.log(personOne.bullets)
personOne.shoot()
console.log(personOne.bullets)

console.log(personTwo.bullets)
personTwo.shoot()
console.log(personTwo.bullets)