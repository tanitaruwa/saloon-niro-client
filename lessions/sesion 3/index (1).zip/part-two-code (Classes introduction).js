class Man{

    constructor(name, health, bullets, money){

        this.name = name
        this.health = health
        this.bullets = bullets
        this.money = money

    }

    run(){
       console.log(this.name + " is running"); 
    }

    jump(){
        console.log(this.name + " is jumping");
    }

    shoot(){
        console.log(this.name + " is shooting");
        this.bullets = this.bullets - 1
    }


}

let personOne = new Man("Carl Johnson", 100, 50 , 1000)
let personTwo = new Man("Franklin Clinton", 100, 500 , 1000)

console.log(personOne.bullets)
personOne.shoot()
console.log(personOne.bullets)

console.log(personTwo.bullets)
personTwo.shoot()
console.log(personTwo.bullets)
