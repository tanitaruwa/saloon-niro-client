import { NextResponse } from "next/server";

export function GET(){

    console.log("Get request received");
    
}

export async function POST(req){

    const body = await req.json()

    const message = "Good morning "+body.designation+" "+body.student+" Welcome to the "+body.subject+" class"

    console.log(message);

    return NextResponse.json(
        {
            welcomeNote : message
        }
    )

}

export function PUT(){

    console.log("Put request received");

}

export function DELETE(){

    console.log("Delete request received");

}